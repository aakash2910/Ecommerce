﻿namespace ECommerce.Models
{
    public class Category
    {
        private int _categoryID { get; set; }
        private string _categoryName { get; set; }
        private Product _product { get; set; }
    }
}
