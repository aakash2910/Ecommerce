﻿namespace ECommerce.Models
{
    public class Discount
    {
        private int _discountId { get; set; }
        private string _name { get; set;}

        private string _description { get; set;}

        private decimal _percentage { get; set; }

    }
}
